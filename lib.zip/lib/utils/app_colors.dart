import 'hex_color.dart';

final mainAppColor = HexColor('5B3CB3');
final hintColor = HexColor('B1B1B1');
final accentColor = HexColor('00732F');
final toastWarningColor = HexColor('FF1937');
final orangeColor = HexColor('E55603');
